(function(){
    var app = angular.module('app');
    app.directive('c3NamedmdxChart', ['$log','$rootScope','$tm1Ui','$timeout', function($log, $rootScope,$tm1Ui,$timeout) {
        return {
            templateUrl: 'html/c3-namedmdx-chart.html',
            scope:{
                componentHeight:'@',
                heading:'@',
                chartTargetId:'@',
                mdxId:'@',
                mdxParam:'@',
                cubeName:'@',
                dimensionAlias:'@',
                className: '@',
                showChart:'@',
                chartPosition : '@',
                hideTable:'@',
                chartType:'@',
                chartDriver:'@',
                chartDimensionDriver:'@',
                chartRowDriver:'@',
                chartRowDimensionDriver:'@',
                chartLedgendsShow:'@',
                chartRotateAxis:"@"
          }, 
          link:function(scope, $elements, $attributes, directiveCtrl, transclude){
            scope.componentHeight = $attributes.componentHeight;
            scope.heading = $attributes.heading;
             scope.mdxId = $attributes.mdxId;
             scope.typeOptions=["bar","bar","spline","line","bar","area"];
             scope.colorArray = ['#1f77b4', '#aec7e8', '#ff7f0e', '#ffbb78', '#2ca02c', '#98df8a', '#d62728', '#ff9896', '#9467bd', '#c5b0d5', '#8c564b', '#c49c94', '#e377c2', '#f7b6d2', '#7f7f7f', '#c7c7c7', '#bcbd22', '#dbdb8d', '#17becf', '#9edae5'];
             scope.chart = null;
             scope.config = {};
             scope.config.data = {};
             scope.config.type = {};
             scope.config.categories = [];
             scope.config.series = [];
             scope.cubename = $attributes.cubeName;
             scope.chartType = $attributes.chartType;
             scope.mdxParam = JSON.parse($attributes.mdxParam);
             scope.chartDriver = $attributes.chartDriver;
             scope.chartDimensionDriver = $attributes.chartDimensionDriver;
             scope.chartRowDriver = $attributes.chartRowDriver;
             scope.chartRowDimensionDriver = $attributes.chartRowDimensionDriver;
             scope.className = $attributes.className;
             scope.chartLedgendsShow = $attributes.chartLedgendsShow;
              

             if($attributes.chartRotateAxis === 'true'){
                scope.chartRotateAxis = true;
             }else{
                scope.chartRotateAxis = false;
             }
             scope.resize = false;
             scope.groupSelect = false;
             if($attributes.hideTable === 'true'){
                scope.hideTable = $attributes.hideTable;
             }else{
                 
             }
             scope.popoverContent = '';
             scope.seeParam = function(json){ 
              
                var returnTemp= '';
                var param  = angular.fromJson(json).parameters
                _.forEach(param, function(el,index,arr){
                 
                    if((index).toLowerCase() === (scope.chartDriver).toLowerCase() ){
                        returnTemp =  returnTemp + "<span styl='color:#ddd'><i class='fa fa-th-list'></i> " +index +" - "+el+ " Selected</span><br>"
                    }else{
                        returnTemp =  returnTemp + "" +index +" - "+el+ "<br>"
                    }
                    
                     
                 });
                return returnTemp;
             }
             scope.showChartSetup = $attributes.showChart;
             scope.chartPosition = $attributes.chartPosition;
             scope.chartTargetId = $attributes.chartTargetId;
             scope.findElementPosition = function(nameToFind, arrayToLoop){
                var returnVal = ''
                for(var bb = 0; bb < arrayToLoop.length; bb++){
                        // 
                         if(arrayToLoop[bb] === nameToFind){
                             console.log(bb + "" +arrayToLoop[bb]);
                            returnVal = bb;
                         }
                };
                scope.chartDriverPosition =  returnVal;
             }
             
             scope.getData = function(){
                scope.loading = true;
                scope.config.data = {};
                scope.config.categories = [];
                        scope.config.series = [];
                 $tm1Ui.cubeExecuteNamedMdx($rootScope.defaults.settingsInstance, scope.mdxId, scope.mdxParam).then(function (result) {
                     if (!result.failed) {
                       
                         scope.dataset = $tm1Ui.resultsetTransform($rootScope.defaults.settingsInstance, scope.cubeName, result, scope.dimensionAlias);
                     
                         var options = { preload: false, watch: false, pageSize: 10000 };
                         if (scope.table) {
                             options.index = scope.table.options.index;
                             options.pageSize = scope.table.options.pageSize;
                         }
                         
                         //console.log(scope.dataset, "scope.dataset")
                         scope.table = $tm1Ui.tableCreate(scope, scope.dataset.rows, options);
                         scope.loading = false;
                         // console.log(scope.table.data());
                         _.forEach(scope.dataset.headers[0].columns,function(el,rowIndex,arr){
                            if(el['element']['attributes']['Description'] != undefined){
                                scope.config.categories.push(el['element']['attributes']['Description'])
                            }else{
                                scope.config.categories.push(el.key) 
                            }
                            
                         });
                         scope.findElementPosition($rootScope.defaults[scope.chartDriver],scope.config.categories );
                         _.forEach(scope.table.data(),function(el,rowIndex,arr){
                            scope.config.series.push(arr[rowIndex]['elements']['0']['element']['attributes']['Description'])
                           //  console.log( arr[rowIndex]['elements']['0']['element']['attributes']['Description']);
                         });
                         _.forEach(scope.table.data(),function(el,rowIndex,arr){
                            var nameToUse = ''; 
                            if(arr[rowIndex]['elements']['0']['element']['attributes']['Description'] != undefined){
                                nameToUse = arr[rowIndex]['elements']['0']['element']['attributes']['Description']
                             }else{
                                 console.log(arr[rowIndex]['elements']['0'].key, "#####")
                                nameToUse = arr[rowIndex]['elements']['0'].key
                             }
                             scope.config.data[nameToUse] = [];
                             scope.config.type['type'+rowIndex] = [];
                                 
                                 for(var tt = 0 ; tt < arr[rowIndex]['cells'].length; tt++){
                                     
                                 scope.config.data[nameToUse].push(parseInt(arr[rowIndex]['cells'][tt].value));
                                 }   
                                 
                                 scope.config.type['type'+rowIndex ] = scope.chartType;
                             
                                 // console.log( arr[rowIndex]['elements']['0']['element']['attributes']['Description'], scope.config.data[arr[rowIndex]['elements']['0']['element']['attributes']['Description']],"Description");
                         });
                          if(scope.table.data().length > 0 ){
                              if(scope.table.data()[0]['cells'] != 'undefined' ){
                                    scope.creatChart();
                              }
                            
                          }
                          
                     }else{
                         scope.loading = false;
                     }
                 }); 
             }
             
 
             scope.creatChart = function() {
             
                 $timeout(
                     function(){
                         
                         var currentWidth =  scope.getElementWidth('c3chart'+scope.chartTargetId)-20;
                         var currentHeight =  scope.getElementHeight('c3chart'+scope.chartTargetId);
                        if(currentHeight > scope.componentHeight ){
                             
                         }else{
                            currentHeight  =  scope.componentHeight-5
                         }
                         var config = {}; 
                         config.bindto = '#c3chart'+scope.chartTargetId;
                         config.size = {"height":currentHeight, 'width':currentWidth}
                         config.data = { onclick: function (d, element) { 
                              scope.chartDriverPosition = d.x;
                                if(scope.chartType === 'pie'){ 
                               
                                $tm1Ui.dimensionElement($rootScope.defaults.settingsInstance, scope.chartDimensionDriver, (d.id).split('_').join(' ')).then(function (result) {
                                    if (!result.failed) {
                                  
                                        //console.log('result', result);
                                         $rootScope.defaults[(scope.chartDriver)]  = result[0].Name;
                                 
                                    }   
                                });   
                          
                            }else{
                                
                                $tm1Ui.dimensionElement($rootScope.defaults.settingsInstance, scope.chartDimensionDriver, scope.config.categories[d.x]).then(function (result) {
                                    if (!result.failed) {
                                        //console.log(result)
                                       
                                        $rootScope.defaults[(scope.chartDriver)]  = result[0].Name;
                                        
                                    }
                                });
                            }   
                           
                        }};
                         config.data.json = {};
                         config.area = {};
                        
                         config.data.types =[];
                         config.data.json.data = [];
                         //console.log(scope.config.data, scope.table.data()[0]['cells'].length);
                         if(scope.groupSelect){
                            config.tooltip =  { 
                                "grouped": true
                                 
                        }               
                         }else{
                            config.tooltip =  { 
                                "grouped": false 
                                  }       
                         }
                         _.forEach(scope.config.data, function(element,index,array){
                             
                            // console.log('element = '+element+' : rowIndex = '+index+' : arr = '+array+'');
                             if(scope.table.data()[0]['cells'].length > 1){
                                 config.data.types[index] = scope.chartType;
                                  
                             }else{
                                 if(scope.chartType === 'line'){
                                     config.data.types[index] = 'bar' ;
                                 }else{
                                      config.data.types[index] = scope.chartType ;
                                 }
                                
                                 
                             }
                             config.groups =  [
                                scope.config.series
                            ]
                             config.data.order =  'asc';
                             config.data.json[index] = element;
                                 
                         }); 
                         config.onresized =  function () { 
                            // console.log("resized")
                            
                                if(!scope.resize && !scope.loading && scope.table.data().length > 0 ){
                                    scope.resize = true;
                                    if(scope.table.data()[0]['cells'] != 'undefined' ){
                                        scope.creatChart();
                                    }
                              
                                }
                        }
                        if(scope.chartRotateAxis === true || scope.chartRotateAxis === 'true'){
                                config.axis = {
                                    "rotated":true,
                                    "x" : {
                                       "type": "category", 
                                       "tick": { 
                                            "multiline": false, 
                                            "culling": {  "max": 10  }
                                       },
                                       "categories":scope.config.categories
                                   },
                                   "y":{
                                       "label":{
                                           "text":$rootScope.defaults.measure,
                                           "position":"inner-right"}
                                   }
                               };
                            }else{
                                config.axis = {
                                    "rotated":false,
                                    "x" : {
                                       "type": "category", 
                                       "tick": { 
                                            "multiline": false, 
                                            "culling": {  "max": 10  }
                                       },
                                       "categories":scope.config.categories
                                   },
                                   "y":{
                                     
                                    "tick": {
                                        format: d3.format("s")
                                    },
                                       "label":{
                                           "text":$rootScope.defaults.measure,
                                           "position":"inner-right"}
                                   }
                               };
                            }
                         
                         config.color =  {
                             "pattern": scope.colorArray
                         }
                         config.legend =  {
                             "show": false
                         }
                         if(scope.chartType === 'line' || scope.chartType === 'area'){
                         config.zoom =  {
                             "enabled": true,
                        
                         }  
                         }else{
                            config.zoom =  {
                                "enabled": false,
                                
                            }  
                         }
                         config.transition =  {
                            "duration": 0
                          }
                         
                         if(scope.table.data()[0]['cells'].length > 1){
                             ;
                            // console.log("####### LENGTH > 2",scope.table.data()[0]['cells'].length )
                         }else{
                             config.data.labels= { format: { y: d3.format('$') } };
                             
                              
                         }
                          
                         config.grid =  {  "x":{ "lines":[{"value": scope.chartDriverPosition, "text": $rootScope.defaults[scope.chartDriver]}] } }
                         //config.data.groups=[['data1','data2']];
                         //config.regions = [{start:0, end:1}];
                         config.area = { zerobased: false};
                         scope.chart = c3.generate(config);	 
                         $rootScope.charts[scope.chartDriver] = scope.chart;
                         scope.loading = false;
                         scope.resize = false;
                         function toggle(id) {
                             scope.chart.toggle(id);
                         }
                 
                     }
                 )
                 scope.seeData = function(data){
                    console.log(data)
                 }
                 scope.mouseDblClickRowElement = function(rowElement, elementName){
                    console.log("DBL CLICKED", rowElement);
                    for(var dd = 0; dd < scope.config.series.length; dd++){
                        if(scope.config.series[dd] === elementName){
                             
                            scope.doubleClickedItem = elementName;
                             
                            
                        }else{
                            if(rowElement['elements'][0]['element']['level'] === 0){
                           scope.chart.toggle(scope.config.series[dd]);
                            }
                        }
                    }
                    if(rowElement['elements'][0]['element']['level'] != 0){
                        $rootScope.defaults[scope.chartRowDriver] =  rowElement['elements'][0]['element']['key'];
                    }
                    
                    
                }
                scope.getParentFromUniqueName = function(uniqueName){
                        
                        var tempStringOne = (uniqueName).split(']').join('');
                        var tempStringTwo = (tempStringOne).split('[').join('');
                        var tempStringThree = (tempStringTwo).split('][').join('');

                        console.log((tempStringThree.split('.')[tempStringThree.split('.').length-1]).split('^')[0]);
                        $rootScope.defaults[scope.chartRowDriver] = (tempStringThree.split('.')[tempStringThree.split('.').length-1]).split('^')[(tempStringThree.split('.')[tempStringThree.split('.').length-1]).split('^').length-2];

                }
                scope.getTopUniqueName = function(uniqueName){
                   var returnVal = 'false'; 
                    if((uniqueName.split('^').length)-1 > 0){
                        returnVal = 'true'; 
                    }else{
                         returnVal = 'false'; 
                    }
                    if(returnVal === 'true'){
                        return true;
                    }else{
                        return false;
                    }
                }
                scope.groupSelected = function(){
                    if( scope.groupSelect  === true){
                        scope.groupSelect = false;

                    }else{
                        scope.groupSelect = true;
                   
                    }
                         scope.creatChart();
                }
                scope.toogleChartElement = function(id) {
                    scope.chart.toggle(id);
                }
                 
                scope.mouseOverRowElement = function(id){
                        
                    scope.chart.focus(id);
                }
                scope.mouseOutRowElement = function(id) {
                    scope.chart.revert();
                }
                scope.mouseClickRowElement = function(id) {
                // console.log(id," clicked ")
                    scope.toogleChartElement(id);
                    
                };
                scope.setColumnElement = function(columnElement){
                $rootScope.defaults[(scope.chartDriver)]  = columnElement;
                }
            }
            scope.getElementWidth = function(ID){
                if(document.getElementById('table'+scope.chartTargetId) != undefined && document.getElementById('table'+scope.chartTargetId) != 'undefined'){
                // scope.currentWidth = document.getElementById(ID).getBoundingClientRect().width;
                // return document.getElementById(ID).getBoundingClientRect().width;
                if(scope.chartLedgendsShow === 'true'){
                    scope.currentWidth = document.getElementById('table'+scope.chartTargetId).getBoundingClientRect().width-110;
                
                    return document.getElementById('table'+scope.chartTargetId).getBoundingClientRect().width-110;
                }else{
                scope.currentWidth = document.getElementById('table'+scope.chartTargetId).getBoundingClientRect().width-40;
                
                return document.getElementById('table'+scope.chartTargetId).getBoundingClientRect().width-40;
                }
            }
        
            }
            scope.getElementHeight = function(ID){
                if(document.getElementById(ID) != undefined && document.getElementById(ID) != 'undefined'){
                    scope.currentHeight = document.getElementById(ID).getBoundingClientRect().height;
                    return document.getElementById(ID).getBoundingClientRect().height;
            
                }
         
            }
           
              
              
           
             
            scope.$watch(function () {
                 return $attributes.mdxParam;
                
                 }, function (newValue, oldValue) { 

                    if(newValue != oldValue && oldValue != undefined){
                         
                        scope.mdxParam =  JSON.parse(newValue);
                        // console.log()
                        
                        scope.getData();
                       
                    }
                    
                   
                   
            })
             
            scope.getData();
            scope.getContainerWidth = function(id){
                if( id != '' && document.getElementById(id) != undefined && document.getElementById(id) != 'undefined'){
                    if(scope.chartLedgendsShow === 'true'){
                        scope.componentWidth =  document.getElementById(id).getBoundingClientRect().width -40;
                    }else{
                        scope.componentWidth =  document.getElementById(id).getBoundingClientRect().width ;
                   
                    }

               
                }

            }
            scope.getContainerHeight = function(id){
                if( id != '' && document.getElementById(id) != undefined && document.getElementById(id) != 'undefined'){
                    scope.componentHeight =  document.getElementById(id).getBoundingClientRect().height - 50;
                    
                }
                 
            }
            scope.getComponentHeight = function(id){
                if( id != '' && document.getElementById(id) != undefined && document.getElementById(id) != 'undefined'){
                   return   document.getElementById(id).getBoundingClientRect().height -40;
                    
                }
                 
            }


            
     scope.cards = [
        {
            title: "escheresque-dark",
            icon:"",
            imageUrl:"https://subtlepatterns.com/patterns/escheresque_ste.png",
            description:"Sublte Pattern Source image below...",
            source: "https://subtlepatterns.com/escheresque-dark/"
        },
        {
            title: "dark sharp edges",
            icon:"",
            imageUrl:"https://subtlepatterns.com/patterns/footer_lodyas.png",
            description:"Sublte Pattern Source image below...",
            source: "https://subtlepatterns.com/dark-sharp-edges/"
        },
        {
            title: "Grey Washed Wall",
            icon:"",
            imageUrl:"https://subtlepatterns.com/patterns/grey_wash_wall.png",
            description:"Sublte Pattern Source image below...",
            source: "https://subtlepatterns.com/grey-washed-wall/"
        }
    ];
        scope.currentCard = {};
        
        scope.isCardRevealed = true;
        scope.flipCard = function() {
            scope.isCardRevealed = !scope.isCardRevealed;
            if(scope.isCardRevealed) {
                scope.generateCard();
            } else {
    
                scope.currentCard = {};
                /*            setTimeout(function() {
    //                scope.isBackHidden = !scope.isCardRevealed;
                }, 0.1 * 1000);
    */            
            }
            /*
            
                
    
            */
        }
        
        scope.generateCard = function() {
            scope.currentCard = {};
            var index = Math.floor((Math.random() * scope.cards.length) + 0);
             scope.currentCard = scope.cards[index];
        }
        


          }
        };
    }]);
    
  
 })();