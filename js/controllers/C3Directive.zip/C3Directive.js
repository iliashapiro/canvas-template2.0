app.controller('C3DirectiveCtrl', ['$scope', '$rootScope', '$log', '$tm1Ui','$timeout', '$interval', function($scope, $rootScope, $log, $tm1Ui, $timeout, $interval) {
   /*
    *     defaults.* are variables that are declared once and are changed in the page, otherwise known as constants in programming languages
    *     lists.* should be used to store any lists that are used with ng-repeat, i.e. tm1-ui-element-list
    *     selections.* should be used for all selections that are made by a user in the page
    *     values.* should store the result of any dbr, dbra or other values from server that you want to store to use elsewhere, i.e. in a calculation
    * 
    *     For more information: https://github.com/cubewise-code/canvas-best-practice
    */
    
 
    $scope.defaults = {};
    $scope.selections = {};
    $scope.lists = {};
    $scope.values = {};
    $rootScope.charts = [];
    $rootScope.pageTitle = 'C3 Directive';
    $scope.mdxParam = { "parameters": {  
        "Version":$rootScope.defaults.version,
        "Year":$rootScope.defaults.year,
        "Period":$rootScope.defaults.period,
        "Week":$rootScope.defaults.week,
        "Day":$rootScope.defaults.day,
        "Legal":$rootScope.defaults.legal,
        "Business":$rootScope.defaults.business,
        "Product":$rootScope.defaults.product,
        "Type":$rootScope.defaults.type,
        "Metric":$rootScope.defaults.metric,
        "Measure":$rootScope.defaults.measure } };
    $scope.dimensionAlias = { "alias": { "Product Category":"Description" } };
    $scope.$watch(function () {
        return $rootScope.defaults.legal;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":$rootScope.defaults.year,
            "Period":$rootScope.defaults.period,
            "Week":$rootScope.defaults.week,
            "Day":$rootScope.defaults.day,
            "Legal":newValue,
            "Business":$rootScope.defaults.business,
            "Product":$rootScope.defaults.product,
            "Type":$rootScope.defaults.type,
            "Metric":$rootScope.defaults.metric,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })

     $scope.$watch(function () {
        return $rootScope.defaults.day;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":$rootScope.defaults.year,
            "Period":$rootScope.defaults.period,
            "Week":$rootScope.defaults.week,
            "Day":newValue,
            "Legal":$rootScope.defaults.legal,
            "Business":$rootScope.defaults.business,
            "Product":$rootScope.defaults.product,
            "Type":$rootScope.defaults.type,
            "Metric":$rootScope.defaults.metric,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
     $scope.$watch(function () {
        return $rootScope.defaults.week;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":$rootScope.defaults.year,
            "Period":$rootScope.defaults.period,
            "Week":newValue,
            "Day":$rootScope.defaults.day,
            "Legal":$rootScope.defaults.legal,
            "Business":$rootScope.defaults.business,
            "Product":$rootScope.defaults.product,
            "Type":$rootScope.defaults.type,
            "Metric":$rootScope.defaults.metric,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
     $scope.$watch(function () {
        return $rootScope.defaults.year;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":newValue,
            "Period":$rootScope.defaults.period,
            "Week":$rootScope.defaults.week,
            "Day":$rootScope.defaults.day,
            "Legal":$rootScope.defaults.legal,
            "Business":$rootScope.defaults.business,
            "Product":$rootScope.defaults.product,
            "Type":$rootScope.defaults.type,
            "Metric":$rootScope.defaults.metric,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
     $scope.$watch(function () {
        return $rootScope.defaults.period;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":$rootScope.defaults.year,
            "Period":newValue,
            "Week":$rootScope.defaults.week,
            "Day":$rootScope.defaults.day,
            "Legal":$rootScope.defaults.legal,
            "Business":$rootScope.defaults.business,
            "Product":$rootScope.defaults.product,
            "Type":$rootScope.defaults.type,
            "Metric":$rootScope.defaults.metric,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
     $scope.$watch(function () {
        return $rootScope.defaults.version;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":newValue,
            "Year":$rootScope.defaults.year,
            "Period":$rootScope.defaults.period,
            "Week":$rootScope.defaults.week,
            "Day":$rootScope.defaults.day,
            "Legal":$rootScope.defaults.legal,
            "Business":$rootScope.defaults.business,
            "Product":$rootScope.defaults.product,
            "Type":$rootScope.defaults.type,
            "Metric":$rootScope.defaults.metric,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
     $scope.$watch(function () {
        return $rootScope.defaults.measure;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":$rootScope.defaults.year,
            "Period":$rootScope.defaults.period,
            "Week":$rootScope.defaults.week,
            "Day":$rootScope.defaults.day,
            "Legal":$rootScope.defaults.legal,
            "Business":$rootScope.defaults.business,
            "Product":$rootScope.defaults.product,
            "Type":$rootScope.defaults.type,
            "Metric":$rootScope.defaults.metric,
            "Measure":newValue } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
     $scope.$watch(function () {
        return $rootScope.defaults.business;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":$rootScope.defaults.year,
            "Period":$rootScope.defaults.period,
            "Week":$rootScope.defaults.week,
            "Day":$rootScope.defaults.day,
            "Legal":$rootScope.defaults.legal,
            "Business":newValue,
            "Product":$rootScope.defaults.product,
            "Type":$rootScope.defaults.type,
            "Metric":$rootScope.defaults.metric,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
     $scope.$watch(function () {
        return $rootScope.defaults.type;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":$rootScope.defaults.year,
            "Period":$rootScope.defaults.period,
            "Week":$rootScope.defaults.week,
            "Day":$rootScope.defaults.day,
            "Legal":$rootScope.defaults.legal,
            "Business":$rootScope.defaults.business,
            "Product":$rootScope.defaults.product,
            "Type":newValue,
            "Metric":$rootScope.defaults.metric,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
     $scope.$watch(function () {
        return $rootScope.defaults.metric;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":$rootScope.defaults.year,
            "Period":$rootScope.defaults.period,
            "Week":$rootScope.defaults.week,
            "Day":$rootScope.defaults.day,
            "Legal":$rootScope.defaults.legal,
            "Business":$rootScope.defaults.business,
            "Product":$rootScope.defaults.product,
            "Type":$rootScope.defaults.type,
            "Metric":newValue,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
     $scope.$watch(function () {
        return $rootScope.defaults.product;
       
        }, function (newValue, oldValue) { 
           if (newValue != oldValue &&  oldValue != 'undefined' && oldValue != null) {
           //console.log("changed the mdxParams", newValue);
           
           $scope.mdxParam = { "parameters": {  
            "Version":$rootScope.defaults.version,
            "Year":$rootScope.defaults.year,
            "Period":$rootScope.defaults.period,
            "Week":$rootScope.defaults.week,
            "Day":$rootScope.defaults.day,
            "Legal":$rootScope.defaults.legal,
            "Business":$rootScope.defaults.business,
            "Product":newValue,
            "Type":$rootScope.defaults.type,
            "Metric":$rootScope.defaults.metric,
            "Measure":$rootScope.defaults.measure } };
            
            $scope.loading = true;
            $timeout(
                function(){
                     $scope.loading = false;
 
                },1000
            )
              
           }
           
          
     })
      
}
]);
